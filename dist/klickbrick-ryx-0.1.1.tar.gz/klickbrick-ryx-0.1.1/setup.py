# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['klickbrick_ryx']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['klickbrick = klickbrick-ryx.cli:main']}

setup_kwargs = {
    'name': 'klickbrick-ryx',
    'version': '0.1.1',
    'description': 'CLI liveproject for Manning',
    'long_description': None,
    'author': 'Ryxai',
    'author_email': 'jmichaelbaum@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
